using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileGenerator : MonoBehaviour
{

    public GameObject Prefab; ///< Field_for_prefab

    ///////////////////////////////////////////
    ///  \brief Method to respawn updates
    ///  \code
    /// void Update()
    /// {
    ///    if (Input.GetMouseButtonUp(0))
    ///     {
    ///        StartCoroutine(Respawn());
    ///    }
    ///
    /// }
    /// \endcode
    ///////////////////////////////////////////

    ///////////////////////////////////////////
    /// \brief Coroutine
    /// \code
    ///IEnumerator Respawn()
    /// {
    ///    yield return new WaitForSeconds(1);
    ///    Rigidbody bullet = Instantiate(Prefab, transform.position, Quaternion.identity).GetComponent<Rigidbody>();
    /// }
    /// \endcode
}
