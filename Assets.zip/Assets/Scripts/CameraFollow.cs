﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public static CameraFollow instance;

    public Transform mainbodyPos; // позиция дудлика

    void Start()
    {
        if (instance == null)                               // пишем эти строчки, чтоб можно было корректно использовать переменные в других скриптах
        {
            instance = this;
        }
    }

    void Update()
    {
        if (mainbodyPos.position.y > transform.position.y) // если позиция дудлика больше позициии камеры
        {
            // то позиция камеры приравнивается к позиции дудлика
            transform.position = new Vector3(transform.position.x, mainbodyPos.position.y, transform.position.z); 
        }
    }

}
