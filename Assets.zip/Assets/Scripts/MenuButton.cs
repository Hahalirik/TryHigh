using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MenuButton : MonoBehaviour
{
  
    public void StartScence()
    {
        SceneManager.LoadScene("TimeOfGame");
    }

    public void Quit()
    {
        Debug.Log("Exit///");
        Application.Quit();
    }

}
