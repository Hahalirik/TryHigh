﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;                          // меня не забудь подключить, мы ж уровень перезагружать будем

public class MainBody : MonoBehaviour
{
    public static MainBody instance;                          // это штучка нужна, чтобы мы могли использовать переменные в этом скрипте в других скриптах

    public Rigidbody2D MainBodyRigid;                         // публичный RB для дудлика

    void Start()
    {
        if (instance == null)                               // пишем эти строчки, чтоб можно было корректно использовать переменные в других скриптах
        {
            instance = this;                               
        }
    }


    public void OnCollisionEnter2D(Collision2D collision)       // столкновение объекта
    {
        if (collision.collider.name == "DeadZone")              // если дудлик сталкивается с объектом с именем "DeadZone"
        {
            SceneManager.LoadScene(1);                          // то уровень перезагружается
        }
    }

}
