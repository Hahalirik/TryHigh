/**
 * \brief Game
 * \author A team led by Kudryavtsev D.E.
 * \date Date of last modification - 04.05.2021
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{

    public Transform cameraPos; ///< Field_for_camera_coordinates

    public GameObject Prefab; ///< Field_for_prefab

    public Vector2 mousePos; ///< Field_for_mouse_coordinates
    public Vector2 speed; ///< Projectile_Velocity_Field

    public float Power; ///< Projectile_Launch_Force_Field

    ///////////////////////////////////////////
    ///  /brief Method to update mouse position, projectile launch force, projectile speed
    ///  /param Prefab Description read above
    ///  /param mousePos Description read above
    ///  /param speed Description read above
    ///  /param Power Description read above
    ///
    /// **Example using
    /// \code
    /// void Update()
    /// {
    ///     if (Input.GetMouseButtonDown(0)) ///< Receiving_Signal_When_Mouse_Key-is-Pressed
    ///     {
    ///     mousePos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
    ///     }
    ///     \endcode
    ///
    /// \code
    /// if (Input.GetMouseButtonUp(0)) ///< Receiving_a_signal_on_mouse_key release
    ///    {
    ///        speed = (mousePos - new Vector2(Input.mousePosition.x, Input.mousePosition.y)) * Power;
    ///        Rigidbody2D projectile = Instantiate(Prefab, new Vector2(mousePos.x, mousePos.y), transform.rotation).GetComponent<Rigidbody2D>();
    ///        projectile.AddForce(speed, ForceMode2D.Impulse);
    ///    }
    ///
    /// } 
    /// \endcode
    //////////////////////////////////////////////
}

