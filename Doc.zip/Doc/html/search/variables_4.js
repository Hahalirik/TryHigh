var searchData=
[
  ['platformprefab',['platformPrefab',['../class_platform_generate.html#aee442c2edcde4ec8450a175123c53815',1,'PlatformGenerate']]],
  ['power',['Power',['../class_example.html#a2e2337dcbd550450033f4756706b4a22',1,'Example']]],
  ['prefab',['Prefab',['../class_example.html#a9ff0f8ae663d77aa6c786bcf4531c27b',1,'Example.Prefab()'],['../class_projectile_generator.html#af9bc9e3ccd5c2620a20615cb3ffeffa0',1,'ProjectileGenerator.Prefab()']]]
];
