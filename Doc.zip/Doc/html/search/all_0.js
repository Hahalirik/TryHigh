var searchData=
[
  ['birdprefab',['BirdPrefab',['../class_projectile.html#a297b25793b1e9ece0a50f2ef68779d54',1,'Projectile']]],
  ['birdspawnerpos',['BirdSpawnerPos',['../class_projectile.html#a860b68a459314479f74df72ee9c80cfd',1,'Projectile']]]
];
