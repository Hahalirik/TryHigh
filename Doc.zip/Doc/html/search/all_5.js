var searchData=
[
  ['oncollisionenter2d',['OnCollisionEnter2D',['../class_main_body.html#abf9744f0b37e6360fa0d07eaf8327c73',1,'MainBody.OnCollisionEnter2D()'],['../class_projectile.html#a8fa2d3cda091a7ea279f1f9ec9c5a065',1,'Projectile.OnCollisionEnter2D()']]]
];
