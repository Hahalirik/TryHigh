var searchData=
[
  ['instance',['instance',['../class_camera_follow.html#a101dc61e219bbfc9c90378cb0f675e47',1,'CameraFollow.instance()'],['../class_main_body.html#a8c982af42e93cba3a4488371499303bb',1,'MainBody.instance()']]]
];
